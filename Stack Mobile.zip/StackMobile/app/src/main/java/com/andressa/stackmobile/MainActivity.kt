package com.andressa.stackmobile

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import net.objecthunter.exp4j.Expression
import net.objecthunter.exp4j.ExpressionBuilder

class MainActivity : AppCompatActivity() {
    lateinit var txt_resultado:TextView // TextView para exibir o resultado da expressão
    lateinit var expressao:TextView  // TextView para exibir a expressão atual
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        //throw java.lang.Exception("bbb")
        // Referenciando elementos da interface de usuário

        // Números de 0 a 9
        var numero_zero:TextView=findViewById(R.id.numero_zero)
        var numero_um:TextView=findViewById(R.id.numero_um)
        var numero_dois:TextView=findViewById(R.id.numero_dois)
        var numero_tres:TextView=findViewById(R.id.numero_tres)
        var numero_quatro:TextView=findViewById(R.id.numero_quatro)
        var numero_cinco:TextView=findViewById(R.id.numero_cinco)
        var numero_seis:TextView=findViewById(R.id.numero_seis)
        var numero_sete:TextView=findViewById(R.id.numero_sete)
        var numero_oito:TextView=findViewById(R.id.numero_oito)
        var numero_nove:TextView=findViewById(R.id.numero_nove)



        var ponto:TextView=findViewById(R.id.ponto)

        // Operadores (+, -, *, /)
        var soma:TextView=findViewById(R.id.soma)
        var subtracao:TextView=findViewById(R.id.subtracao)
        var multiplicacao:TextView=findViewById(R.id.multiplicacao)
        var divisao:TextView=findViewById(R.id.divisao)

        var backspace:ImageView=findViewById(R.id.backspace)  // Botão de apagar um caractere

        var limpar:TextView=findViewById(R.id.limpar)  // Botão de limpar toda a expressão

        var igual:TextView=findViewById(R.id.igual)   // Botão de calcular o resultado

        var mem_som_ent:TextView=findViewById(R.id.mem_som_ent)  // Botão de memória para salvar resultado

        var mem_sub_ent:TextView=findViewById(R.id.mem_sub_ent)  // Botão de memória para recuperar resultado

        expressao=findViewById(R.id.expressao)   // TextView que mostra a expressão atual
        txt_resultado=findViewById(R.id.txt_resultado)  // TextView que mostra o resultado

        // Definindo os listeners de clique para os números e o ponto decimal
        numero_zero.setOnClickListener {
            AcrescentarUmaExpressao( "0", true)
        }

        // Definindo os listeners de clique para os operadores
        numero_um.setOnClickListener {AcrescentarUmaExpressao( "1",  true)}
        numero_dois.setOnClickListener {AcrescentarUmaExpressao( "2", true)}
        numero_tres.setOnClickListener {AcrescentarUmaExpressao( "3", true)}
        numero_quatro.setOnClickListener {AcrescentarUmaExpressao( "4", true)}
        numero_cinco.setOnClickListener {AcrescentarUmaExpressao( "5", true)}
        numero_seis.setOnClickListener {AcrescentarUmaExpressao( "6", true)}
        numero_sete.setOnClickListener {AcrescentarUmaExpressao( "7", true)}
        numero_oito.setOnClickListener {AcrescentarUmaExpressao( "8", true)}
        numero_nove.setOnClickListener {AcrescentarUmaExpressao( "9",true)}
        ponto.setOnClickListener {AcrescentarUmaExpressao( ".", true)}


        //Operadores
        soma.setOnClickListener {AcrescentarUmaExpressao( "+", false)}
        subtracao.setOnClickListener {AcrescentarUmaExpressao( "-", false)}
        multiplicacao.setOnClickListener {AcrescentarUmaExpressao( "*", false)}
        divisao.setOnClickListener {AcrescentarUmaExpressao( "/", false)}

        // Listener para o botão de limpar
        limpar.setOnClickListener {
            expressao.text=""
            txt_resultado.text=""
        }

        // Listener para o botão de apagar um caractere
        backspace.setOnClickListener {

            val string = expressao.text.toString()

            if(string.isNotBlank()){
                expressao.text = string.substring(0,string.length-1)
            }
            txt_resultado.text=""
        }

        // Listener para o botão de calcular o resultado
        igual.setOnClickListener {

            try {
                val expressao = ExpressionBuilder(expressao.text.toString()).build()

                val resultado = expressao.evaluate()
                val longResult = resultado.toLong()

                if (resultado == longResult.toDouble())
                    txt_resultado.text = longResult.toString()
                else
                    txt_resultado.text = resultado.toString()

            }catch (e: Exception){
                Toast.makeText(this, "Expressão invalida", Toast.LENGTH_LONG).show()
            }

        }

        // Listener para o botão de memória (salvar resultado)
        mem_som_ent.setOnClickListener {
            val botao = getSharedPreferences("PREFERENCE_NAME", 0)
            var editor = botao.edit()
            editor.putString("memoria", txt_resultado.text.toString())
            editor.commit()
        }

        // Listener para o botão de memória (recuperar resultado)
        mem_sub_ent.setOnClickListener {
            val botao = getSharedPreferences("PREFERENCE_NAME", 0)
            expressao.text = botao.getString("memoria","")

        }




    }

    // Função para adicionar um caractere à expressão
    fun AcrescentarUmaExpressao(string: String, limpar_dados: Boolean){
        expressao=this@MainActivity.findViewById(R.id.expressao)
        txt_resultado=this@MainActivity.findViewById(R.id.txt_resultado)

        // Se já houver um resultado exibido, limpe a expressão antes de adicionar o próximo caractere
        if (txt_resultado.text.isNotEmpty()){
            expressao.text=""
        }

        if (limpar_dados){
            txt_resultado.text=""
            expressao.append(string)
        }else{
            expressao.append(txt_resultado.text)
            expressao.append(string)
            txt_resultado.text=""
        }

    }

}